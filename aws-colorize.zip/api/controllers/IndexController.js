/**
 * IndexController
 *
 * @description :: Server-side logic for managing indices
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	


  /**
   * `IndexController.rotate()`
   */
  rotate: function (req, res) {
    return res.json({
      todo: 'rotate() is not implemented yet!'
    });
  }
};

